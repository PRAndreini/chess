"""
   By Paul Robert Andreini
    07 Mar 2026

   Code here is LOOSELY based on a YouTube tutorial series, whose playlist is visible at the following link:
        https://www.youtube.com/playlist?list=PLBwF487qi8MGU81nDGaeNE1EnNEPYWKY_

   This code is for EPISODE 16.

   AI FILE is responsible for generating the computer's move (only in the case of 0/1-player game).
"""

## Importing relevant packages...
from ChessEngine16 import GameState
import random

## Dictionary defines the relative values of the pieces, with pawn fixed at "1".
##  NOTE: We give a King value "0", because a player can never lose his/her King (it would be checkmate).
PIECE_SCORES = {
    "P": 1,
    "N": 3,
    "B": 3,
    "R": 5,
    "Q": 9,
    "K": 0
}

## Knights are better in the center.
knight_scores = [
    [1, 1, 1, 1, 1, 1, 1, 1],
    [1, 2, 2, 2, 2, 2, 2, 1],
    [1, 2, 3, 3, 3, 3, 2, 1],
    [1, 2, 3, 4, 4, 3, 2, 1],
    [1, 2, 3, 4, 4, 3, 2, 1],
    [1, 2, 3, 3, 3, 3, 2, 1],
    [1, 2, 2, 2, 2, 2, 2, 1],
    [1, 1, 1, 1, 1, 1, 1, 1]
]

piece_position_scores = {"N": knight_scores}

CHECKMATE = 1000  ## Checkmate is the best-possible move, so set this value very high.
STALEMATE = 0     ## Stalemate is better than losing, but is not as good as winning.

## Recursive-depth: how far do we want to go down the tree?
DEPTH = 3


def get_random_move(vm_list: list()):
    """
       Given a list of valid moves (passed as a parameter), picks one at random.
        This is a BETTER METHOD than trying to find a random number corresponding to the length of valid moves!
    """
    if not vm_list:
        return None
    else:
        return random.choice(vm_list)


def score_material(b):
    """
       Scores the board based purely on material (no positional-advantage considered).
        Parameter "b" is the "GameState.board" field.
        RETURN: score (int).
    """
    score = 0

    for row in b:
        for square in row:
            if square[0] == "w":
                score += PIECE_SCORES[square[1]]
            elif square[0] == "b":
                score -= PIECE_SCORES[square[1]]

    return score


def score_board(gs: GameState):
    """
       Scores not only material, but also positional-advanatages!
        NOTE: POSITIVE is good for white; NEGATIVE is good for black!
    """
    ## Black wins if white is checkmated, else white wins.
    if gs.checkmate:
        if gs.white_to_move:
            return -CHECKMATE  ## Black wins.
        else:
            return CHECKMATE   ## White wins.
    ## If STALEMATE, then nobody wins.
    elif gs.stalemate:
        return STALEMATE

    score = 0

    for row in range(len(gs.board)):
        for col in range(len(gs.board[row])):
            piece = gs.board[row][col]
            if not (piece == "--"):
                ## Score pieces POSITIONALLY, here!
                piece_position_score = 0
                if piece[1] == "N":
                    piece_position_score = piece_position_scores["N"][row][col]

                if piece[0] == "w":
                    score += PIECE_SCORES[piece[1]] + piece_position_score * 0.9
                elif piece[0] == "b":
                    score -= PIECE_SCORES[piece[1]] + piece_position_score * 0.9

    return score


def get_greedy_move(gs: GameState, vm_list: list()):
    """
       Finds the best move based purely on material (no positional advantage considered).
    """
    random.shuffle(vm_list)
    turn_multiplier = 1 if gs.white_to_move else -1
    opponent_min_max_score = CHECKMATE
    best_player_move = None

    for player_move in vm_list:
        gs.make_move(player_move)
        opponent_moves = gs.get_all_valid_moves()
        random.shuffle(opponent_moves)
        opponent_max_score = -CHECKMATE

        if gs.stalemate:
            opponent_max_score = STALEMATE
        elif gs.checkmate:
            opponent_max_score = -CHECKMATE

        ## Only go through this procedure IF THERE IS NOT A MATE ON THE BOARD!
        ##  This probably doesn't have a large impact on efficiency, but we will take it where we can get it!
        else:
            for opponent_move in opponent_moves:
                gs.make_move(opponent_move)
                gs.get_all_valid_moves()  ## Inefficient, but we must call this in order to update our mating-fields.

                if gs.checkmate:
                    score = CHECKMATE
                elif gs.stalemate:
                    score = STALEMATE
                else:
                    score = -turn_multiplier * score_material(b=gs.board)

                if score > opponent_max_score:
                    opponent_max_score = score

                gs.undo_move()

        if opponent_max_score < opponent_min_max_score:
            opponent_min_max_score = opponent_max_score
            best_player_move = player_move

        gs.undo_move()

    return best_player_move


def helper_method_first_call(gs: GameState, vm_list: list()):
    """
       A helper method to call "get_move_nega_max(...)", to initiate the global variable.
    """
    global next_move, counter
    next_move = None
    random.shuffle(vm_list)
    # get_move_min_max(gs=gs, vm_list=vm_list, depth=DEPTH, white_to_move=gs.white_to_move)
    # get_move_nega_max(gs=gs, vm_list=vm_list, depth=DEPTH, turn_multiplier=1 if gs.white_to_move else -1)
    get_move_nega_max_with_alpha_beta_pruning(gs=gs, vm_list=vm_list, depth=DEPTH,
                                              alpha=-CHECKMATE, beta=CHECKMATE,
                                              turn_multiplier=1 if gs.white_to_move else -1)
    return next_move


def get_move_min_max(gs: GameState, vm_list: list(), depth: int, white_to_move: bool):
    """
       Finds the best move via a greedy algorithm, but recursively-so, unlike get_greedy_move(...).
    """
    global next_move
    random.shuffle(vm_list)

    if depth == 0:
        return score_material(b=gs.board)

    if white_to_move:
        max_score = -CHECKMATE

        for m in vm_list:
            gs.make_move(m)
            next_moves = gs.get_all_valid_moves()
            random.shuffle(next_moves)
            score = get_move_min_max(gs=gs, vm_list=next_moves, depth=depth-1, white_to_move=False)

            if max_score > score:
                max_score = score

                if depth == DEPTH:
                    next_move = m

            gs.undo_move()

        return max_score

    else:
        min_score = CHECKMATE

        for m in vm_list:
            gs.make_move(m)
            next_moves = gs.get_all_valid_moves()
            random.shuffle(next_moves)
            score = get_move_min_max(gs=gs, vm_list=next_moves, depth=depth-1, white_to_move=True)

            if min_score < score:
                min_score = score

                if depth == DEPTH:
                    next_move = m

            gs.undo_move()

        return min_score


def get_move_nega_max(gs: GameState, vm_list: list(), depth: int, turn_multiplier: int):
    """
       Similar to the MinMax algorithm, but a bit cleaner; this is NegaMax.
        Instead of param "white_to_move" being a bool, it is an integer on the set {±1}, which we call turn_multiplier.
        In particular, turn_multiplier=1 if it is White's turn; turn_multiplier=-1 if it is Black's turn.

       The idea here is to ALWAYS MAXIMIZE, then multiply by turn_multiplier.
        This gives a maximum for White and a minimum for Black, just like the MinMax algorithm, but with only 1 loop.
    """
    global next_move
    random.shuffle(vm_list)

    if depth == 0:
        return turn_multiplier * score_board(gs=gs)

    max_score = -CHECKMATE
    for m in vm_list:
        gs.make_move(m)

        next_moves = gs.get_all_valid_moves()
        random.shuffle(next_moves)
        score = -get_move_nega_max(gs=gs, vm_list=next_moves, depth=depth-1, turn_multiplier=-turn_multiplier)

        if score > max_score:
            max_score = score

            if depth == DEPTH:
                next_move = m

        gs.undo_move()

    return max_score


def get_move_nega_max_with_alpha_beta_pruning(gs: GameState, vm_list: list(), depth: int,
                                              alpha, beta, turn_multiplier: int):
    """
       Similar to the MinMax algorithm, but a bit cleaner; this is NegaMax.
        Instead of param "white_to_move" being a bool, it is an integer on the set {±1}, which we call turn_multiplier.
        In particular, turn_multiplier=1 if it is White's turn; turn_multiplier=-1 if it is Black's turn.

       The idea here is to ALWAYS MAXIMIZE, then multiply by turn_multiplier.
        This gives a maximum for White and a minimum for Black, just like the MinMax algorithm, but with only 1 loop.

       This version includes ALPHA-BETA PRUNING, which "cuts off" worse "branches" when it detects no improvment.
    """
    global next_move
    random.shuffle(vm_list)

    if depth == 0:
        return turn_multiplier * score_board(gs=gs)

    ## LATER -- implement MOVE ORDERING: checks, captures, attacks, defending.
    max_score = -CHECKMATE
    for m in vm_list:
        gs.make_move(m)

        next_moves = gs.get_all_valid_moves()
        random.shuffle(next_moves)
        score = -get_move_nega_max_with_alpha_beta_pruning(gs=gs, vm_list=next_moves, depth=depth-1,
                                                           alpha=-beta, beta=-alpha,
                                                           turn_multiplier=-turn_multiplier)

        if score > max_score:
            max_score = score

            if depth == DEPTH:
                next_move = m

        gs.undo_move()

        ## Pruning happens here!
        if max_score > alpha:
            alpha = max_score

        ## Stop looking, HERE, because our new max-score is worse for our opponent than his/her best score is for us!
        if alpha >= beta:
            break

    return max_score

## E.O.F.
